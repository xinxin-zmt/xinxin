﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp1

{
    public partial class denglu : Form
    {          
        public denglu()
        {
            InitializeComponent();
            
        }       
        private void button2_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            zhuce zc = new zhuce(this);
            zc.Show();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = "Data Source=.\\Sql2016;" + "" +
                "Initial Catalog=study;uid=sa;pwd=123";
            conn.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn;
            cmd.CommandType = CommandType.Text;
            string sql = "select username,userpsw from users where userName=@user";
            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@user",textBox1.Text)
             };
            cmd.CommandText = sql;
            cmd.Parameters.AddRange(parameters);
            DataSet shuju = new DataSet();
            SqlDataAdapter adt = new SqlDataAdapter();
            adt.SelectCommand = cmd;
            adt.Fill(shuju, "userinfo");
            conn.Close();
            if (shuju.Tables["userinfo"].Rows.Count > 0)
            {
                if (textBox2.Text != shuju.Tables["userinfo"].Rows[0][1].ToString())
                {
                    MessageBox.Show("密码错误");
                    textBox2.Text = "";
                }
                else
                {
                    MessageBox.Show("登录成功");
                    this.Hide();
                    yhgl yhgl = new yhgl(this);
                    yhgl.Show();
                    this.textBox2.Text = "";
                }
            }
            else
            {
                MessageBox.Show("用户名不存在");
                textBox1.Text = "";
                textBox2.Text = "";
            }
            cmd.Parameters.Clear();
            cmd.Dispose();
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13 && textBox1.Text != "")
            {
                this.textBox2.Focus();
            }
            else if(e.KeyChar==(char)13&&textBox1.Text=="")
            {
                this.AcceptButton = button2;
            }
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13 && textBox2.Text != "")
            {
                this.AcceptButton = button1;
            }
        }
    }
}
