﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace 注册登录
{
    public partial class Form1 : Form
    {
        public denglu()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            zhuce zhuce = new zhuce(this);
            zhuce.show();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = "Data Source=.\\Sql2016;" + "" +
                "Initial Catalog=study;uid=sa;pwd=123";
            conn.Open();

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn;
            cmd.CommandType = CommandType.Text;
            string sql = "select username,userpsw from users where userName=@user";
            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@user",textBox1.Text)
             };
            cmd.CommandText=sql;
            cmd.Parameters.AddRange(parameters);
            DataSet shuj = new DataSet();
            SqlDataAdapter adt = new SqlDataAdapter();
            adt.SelectCommand=cmd;
            adt.Fill(shuju,"userinfo");
            conn.Close();
            if(shuju.Tables["userinfo"].Row.Count>0)
            {
            if(textBox2.Text!=shuju.Table["userinfo"].Row[0][1].ToString())
                {
                MessageBox.Show("密码错误");
                textBox2.Text="";
                }
            else
                {
                MessageBox.Show("登录成功");
                this.Hide();
                yhgl yhgl = new yhgl(this);
                yhgl.Show();
                this.textBox2.Text= "";
                }
            }
      }
    }
}
