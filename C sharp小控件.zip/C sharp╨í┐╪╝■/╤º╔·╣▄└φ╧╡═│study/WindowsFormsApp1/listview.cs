﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class listview : Form
    {
        public listview()
        {
            InitializeComponent();
        }

        private void listview_Load(object sender, EventArgs e)
        {
            listView1.Columns.Add("登录名");
            listView1.Columns.Add("姓名",-1);
            listView1.Columns.Add("出生年月");
            listView1.Columns.Add("邮箱");

            SqlConnection conn = new SqlConnection();
            conn.ConnectionString= "Data Source=.\\Sql2016;" + "" +
                "Initial Catalog=study;uid=sa;pwd=123";
            conn.Open();

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn;
            cmd.CommandType = CommandType.Text;
            string sql = "select username,cn,birth,email from users";
            cmd.CommandText = sql;

            DataSet shuju = new DataSet();
            SqlDataAdapter adt = new SqlDataAdapter();
            adt.SelectCommand = cmd;
            adt.Fill(shuju, "inf");
            DataTable dt = shuju.Tables["inf"];
            conn.Close();

            for(int i = 0; i < dt.Rows.Count; i++)
            {
                listView1.Items.Add(dt.Rows[i][0].ToString());
                listView1.Items[i].SubItems.Add(dt.Rows[i][1].ToString());
                listView1.Items[i].SubItems.Add(dt.Rows[i][2].ToString());
                listView1.Items[i].SubItems.Add(dt.Rows[i][3].ToString());
            }
            listView1.AutoResizeColumns(ColumnHeaderAutoResizeStyle.ColumnContent);

            cmd.Dispose();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count==0)
            {
                SqlConnection conn = new SqlConnection();
                conn.ConnectionString = "Data Source=.\\Sql2016;" + "" +
                "Initial Catalog=study;uid=sa;pwd=123";
                conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.Text;
                string sql = "delete from users where username=@username";
                SqlParameter[] parameters = new SqlParameter[]
                {
                    new SqlParameter("@username",listView1.SelectedItems[0].Text)
                };
                cmd.CommandText = sql;
                cmd.Parameters.AddRange(parameters);
                try//可能出现异常
                {
                    cmd.ExecuteNonQuery();
                    listView1.Items.Remove(listView1.SelectedItems[0]);
                }
                catch (Exception err)//出现异常，捕获异常
                {
                    MessageBox.Show("删除失败！"+err.ToString());
                }
                finally//无论是否异常都要进行
                {
                    cmd.Parameters.Clear();
                    cmd.Dispose();
                }
            }
        }
    }
}
