﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class yhgl : Form
    {
        //长连接不能改封装
        denglu denglu;
        SqlDataAdapter adt;
        SqlConnection conn;
        
        public yhgl(denglu denglu)
        {
            InitializeComponent();
            this.denglu = denglu;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            this.denglu.Show();
        }
        private void yhgl_Load(object sender, EventArgs e)
        {
            conn = new SqlConnection();
            conn.ConnectionString = "Data Source=.\\Sql2016;" + "" +
                "Initial Catalog=study;uid=sa;pwd=123";
            conn.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn;
            cmd.CommandType = CommandType.Text;
            string sql = "select * from users";
            cmd.CommandText = sql;
            DataSet shuju = new DataSet();
            adt = new SqlDataAdapter();
            adt.SelectCommand = cmd;
            adt.Fill(shuju, "inf");
            dataGridView1.DataSource = shuju.Tables["inf"];
        }
        private void dataGridView1_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if(e.ColumnIndex == 1)
            {
                if (e.Value != null && e.Value.ToString().Length > 0)
                {
                    e.Value = new string ('*',e.Value.ToString().Length);
                }       
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            DataTable dt = (DataTable)dataGridView1.DataSource;
            SqlCommandBuilder scb = new SqlCommandBuilder(adt);
            adt.Update(dt);
            MessageBox.Show("保存成功");
        }

        private void yhgl_FormClosing(object sender, FormClosingEventArgs e)
        {
            conn.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            listview listview = new listview();
            listview.Show();
        }
    }
}
