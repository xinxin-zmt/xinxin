﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class zhuce : Form
    {
        denglu  dl;
        public zhuce(denglu dl)
        {
            InitializeComponent();
            this.dl = dl;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = "Data Source=.\\Sql2016;" + "" +
                "Initial Catalog=study;Integrated Security=true";
            conn.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn;
            cmd.CommandType = CommandType.Text;
            string sql = "insert into users values(@name,@psw,@cn,@birth,@email)";
            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@name",textBox1.Text),
                new SqlParameter("@psw",textBox2.Text),
                new SqlParameter("@cn",textBox4.Text),
                new SqlParameter("@birth",dateTimePicker1.Value.ToString("yyyy-MM-dd")),
                new SqlParameter("@email",textBox5.Text),
             };
            if(textBox1.Text!="" && textBox2.Text != "" && textBox3.Text != "")
            {
                if (textBox2.Text==textBox3.Text)
                {
                    cmd.CommandText = sql;
                    cmd.Parameters.AddRange(parameters);
                    try
                    {
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("注册成功");
                        conn.Close();
                        this.Close();
                        dl.Show();
                    }
                    catch (Exception err)
                    {
                        MessageBox.Show(err.ToString());
                    }
                    finally
                    {
                        cmd.Parameters.Clear();
                        cmd.Dispose();                  
                    }
                }
                else
                {
                    MessageBox.Show("两次密码输入不一致！");
                    textBox2.Text = "";
                    textBox3.Text = "";
                }
            }
            else
            {
                MessageBox.Show("请完善信息！");
                textBox2.Text = "";
                textBox3.Text = "";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            dl.Show();
        }

        private void linkLabel1_MouseMove(object sender, MouseEventArgs e)
        {
            linkLabel1.Cursor = Cursors.Hand;
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar==(char)13&&textBox1.Text!="")
            {
                this.textBox2.Focus();
            }
            if (e.KeyChar==(char)27)
            {
                dl.Show();
                this.Close();
            }
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar==(char)13&&textBox2.Text!="")
            {
                this.textBox3.Focus();
            }
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13 && textBox3.Text != "")
            {
                this.textBox4.Focus();
            }
        }

        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13 && textBox4.Text != "")
            {
                this.textBox5.Focus();
            }
        }

        private void dateTimePicker1_KeyPress(object sender, KeyPressEventArgs e)
        {
            this.AcceptButton = button1;
        }

        private void textBox5_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13 && textBox5.Text != "")
            {
                this.dateTimePicker1.Focus();
            }
        }
    }
}
