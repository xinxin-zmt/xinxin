﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class listview : Form
    {
        public listview()
        {
            InitializeComponent();
        }
        int flag;//flag=0增加，flag=1删除，flag=2修改
        string birth;
        private void listview_Load(object sender, EventArgs e)
        {
            panel1.Visible = false;

            listView1.View = View.Details;
            listView1.Columns.Add("登录名");
            listView1.Columns.Add("姓名", -1);
            listView1.Columns.Add("密码");
            listView1.Columns.Add("出生年月");
            listView1.Columns.Add("邮箱");

            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = "Data Source=.\\Sql2016;" + "" +
                "Initial Catalog=study;uid=sa;pwd=123";
            conn.Open();

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn;
            cmd.CommandType = CommandType.Text;
            string sql = "select username,userpsw,cn,birth,email from users";
            cmd.CommandText = sql;

            DataSet shuju = new DataSet();
            SqlDataAdapter adt = new SqlDataAdapter();
            adt.SelectCommand = cmd;
            adt.Fill(shuju, "inf");
            DataTable dt = shuju.Tables["inf"];
            conn.Close();
            listView1.GridLines = true;
            listView1.FullRowSelect = true;
            listView1.Scrollable = true;
            listView1.MultiSelect = false;

            if (dt.Rows.Count == 0) return;
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                string x = new string('*', dt.Rows[i][1].ToString().Length);
                listView1.Items.Add(dt.Rows[i][0].ToString());
                listView1.Items[i].SubItems.Add(dt.Rows[i][2].ToString());
                listView1.Items[i].SubItems.Add(x);
                listView1.Items[i].SubItems.Add(dt.Rows[i][3].ToString());
                listView1.Items[i].SubItems.Add(dt.Rows[i][4].ToString());
            }
            listView1.AutoResizeColumns(ColumnHeaderAutoResizeStyle.ColumnContent);

            cmd.Dispose();
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count == 0) return;
            else
            {
                textBox1.Text = listView1.SelectedItems[0].Text;
                textBox2.Text = listView1.SelectedItems[0].SubItems[1].Text;
                textBox3.Text = listView1.SelectedItems[0].SubItems[2].Text;
                birth = listView1.SelectedItems[0].SubItems[3].Text;
                if (birth != "")
                {
                    dateTimePicker1.Value = Convert.ToDateTime(birth);
                }
                textBox4.Text = listView1.SelectedItems[0].SubItems[4].Text;
            }

        }
        private void button2_Click_1(object sender, EventArgs e)
        {
            flag = 0;
            torf();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            flag = 1;
            torf();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            flag = 2;
            torf();
        }
        void torf()
        {
            panel1.Visible = true;
            textBox1.Enabled = textBox2.Enabled = textBox3.Enabled = textBox4.Enabled = dateTimePicker1.Enabled = true;
            if (flag == 0)
            {
                textBox1.Text = textBox2.Text = textBox3.Text = textBox4.Text = "";
                dateTimePicker1.Value = DateTime.Now;
                textBox3.Enabled = true;
                textBox3.Visible = true;
            }
            if (flag == 1)
            {
                label3.Visible = false;
                textBox3.Visible = false;
                textBox3.Enabled = textBox1.Enabled = textBox2.Enabled = textBox3.Enabled = dateTimePicker1.Enabled = false;
            }
            if (flag == 2)
            {
                label3.Visible = false;
                textBox3.Visible = false;
                textBox3.Enabled = textBox1.Enabled = false;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = "Data Source=.\\Sql2016;" + "" +
                "Initial Catalog=study;Integrated Security=true";
            conn.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn;
            cmd.CommandType = CommandType.Text;
            if (flag == 0)
            {
                if (textBox1.Text != "")
                {
                    try
                    {
                        string sql = "insert users values(@name,@psw,@cn,@birth,@email)";
                        SqlParameter[] parameters = new SqlParameter[]
                        {
                           new SqlParameter("@name",textBox1.Text),
                           new SqlParameter("@psw",textBox3.Text),
                           new SqlParameter("@cn",textBox2.Text),
                           new SqlParameter("@birth",dateTimePicker1.Value.ToString("yyyy-MM-dd")),
                           new SqlParameter("@email",textBox4.Text),
                        };
                        cmd.CommandText = sql;
                        cmd.Parameters.AddRange(parameters);
                        cmd.ExecuteNonQuery();
                    }
                    catch (Exception)
                    {
                        MessageBox.Show("添加失败");
                        return;
                    }
                    MessageBox.Show("添加成功");
                }
                else
                {
                    MessageBox.Show("登录名不能为空");
                }
                listView1.Items.Add(textBox1.Text);
                listView1.Items[listView1.Items.Count - 1].SubItems.Add(textBox2.Text);
                listView1.Items[listView1.Items.Count - 1].SubItems.Add(textBox3.Text);
                listView1.Items[listView1.Items.Count - 1].SubItems.Add(dateTimePicker1.Value.ToString("yyyy-MM-dd"));
                listView1.Items[listView1.Items.Count - 1].SubItems.Add(textBox4.Text);
            }
            else if (flag == 1)
            {
                if (listView1.SelectedItems.Count==0)
                {
                    MessageBox.Show("请先选择需要删除的列");
                    return;
                }
                try
                {
                    string sql = string.Format("delete from users where username=@name");
                 SqlParameter[] parameters = new SqlParameter[]
                  {
                   new SqlParameter("@name",listView1.SelectedItems[0].SubItems[0].Text)
                  };
                   cmd.CommandText = sql;
                   cmd.Parameters.AddRange(parameters);
                   cmd.ExecuteNonQuery();
                }
                catch (Exception)
                {
                   MessageBox.Show("删除失败");
                   return;
                }
                MessageBox.Show("删除成功");
                listView1.SelectedItems[0].Remove();
                textBox1.Text = textBox2.Text = textBox3.Text = textBox4.Text = "";
                panel1.Visible = false;
                dateTimePicker1.Value = DateTime.Now;
            }
            else if (flag == 2)
            {
                try
                {
                    string sql = string.Format("update users set cn=@cn,birth=@birth,email=@email where username=@name");
                    SqlParameter[] parameters = new SqlParameter[]
                     {
                       new SqlParameter("@name",textBox1.Text),
                       new SqlParameter("@psw",textBox3.Text),
                       new SqlParameter("@cn",textBox2.Text),
                       new SqlParameter("@birth",dateTimePicker1.Value.ToString("yyyy-MM-dd")),
                       new SqlParameter("email",textBox4.Text),

                     };
                    cmd.CommandText = sql;
                    cmd.Parameters.AddRange(parameters);
                    cmd.ExecuteNonQuery();
                }
                catch (Exception)
                {
                    MessageBox.Show("修改失败");
                    return;
                }
                MessageBox.Show("修改成功");
                listView1.SelectedItems[0].SubItems[2].Text = textBox3.Text;
                listView1.SelectedItems[0].SubItems[1].Text = textBox2.Text;
                listView1.SelectedItems[0].SubItems[3].Text = dateTimePicker1.Value.ToString("yyyy-MM-dd");
                listView1.SelectedItems[0].SubItems[4].Text=textBox4.Text;
            }
            conn.Close();
        }
    }
}
