﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 随机字母
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public void rand()
        {
            Random a1 = new Random();


            for (int i = 0; i < 20; i++)
            {
                int s = a1.Next(0, 2);
                if (s == 0)
                {
                    Big();
                    continue;
                }
                if (s == 1)
                {
                    Small();
                    continue;
                }

            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            rand();
           
            
        }
        Random big = new Random();
        Random small = new Random();
        public void Big()
        {
            int x = big.Next(65, 91);
            char a = (char)x;
            label1.Text += a;
            labelarray[k] = a.ToString();
            k++;
        }
        int k = 0;
        public void Small()
        {
            int x = big.Next(97, 123);
            char a = (char)x;
            label1.Text += a;
            labelarray[k] = a.ToString();
            k++;

        }
        string[] labelarray=new string[20];
        private void button1_Click(object sender, EventArgs e)
        {
            label1.Text = "";
            k = 0;
            rand();
            textBox1.Enabled = true;
            textBox1.Text = "";
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            label2.Text = "";
            if (textBox1.Text.Length == label1.Text.Length)
            {
                textBox1.Enabled = false;
                string x = textBox1.Text . ToString();
               char[] textboxarrary = x.ToCharArray();
               for(int i = 0; i < 20; i++)
                {
                    if (textboxarrary[i].ToString() == labelarray[i])
                    {
                        label2.Text += "A";
                    }
                    else
                    {
                        label2.Text += "B";
                    }
                }

            }
        }
    }
}
