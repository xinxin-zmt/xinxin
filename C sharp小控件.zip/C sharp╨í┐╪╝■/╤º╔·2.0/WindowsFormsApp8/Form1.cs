﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string[] name = { "张三", "李四", "王五", "赵六" };
            //listview1
            listView1.View = View.Details;
            listView1.Columns.Add("学号", 100);
            listView1.Columns.Add("姓名", 100);
            listView1.Columns.Add("班级", 100);
            listView1.Columns.Add("年龄", 100);
            listView1.FullRowSelect = true;
            listView1.GridLines = true;
            listView1.FullRowSelect = true;
            for(int i = 1; i < 5; i++)
            {
                listView1.Items.Add("00"+i);
                listView1.Items[i-1].SubItems.Add(name[i-1]);
                listView1.Items[i - 1].SubItems.Add("信管"+(i)+"班");
                listView1.Items[i - 1].SubItems.Add((18+i).ToString());
            }
        }

        bool flag = true;
        private void listView_ItemSelectionChanged(object sender, EventArgs e)
        {
            if (flag == false) { flag = true; return; }
            textBox1.Text = listView1.SelectedItems[0].Text; ;
            textBox2.Text = listView1.SelectedItems[0].SubItems[1]. Text;
            textBox3.Text = listView1.SelectedItems[0].SubItems[2].Text;
            textBox4.Text = listView1.SelectedItems[0].SubItems[3].Text;
            flag = false;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if(listView1.SelectedItems.Count!=0)
               listView1.SelectedItems[0].Text=textBox1.Text;
            
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count != 0)
                listView1.SelectedItems[0].SubItems[1].Text=  textBox2.Text  ;
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count != 0)
                listView1.SelectedItems[0].SubItems[2].Text = textBox3.Text;
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count != 0)
                listView1.SelectedItems[0].SubItems[3].Text = textBox4.Text;
        }
        string[] temp = new string[4];
        string[] temp1 = new string[4];
        public void save()
        {
            temp[0] = listView1.SelectedItems[0].Text;
            temp[1] = listView1.SelectedItems[0].SubItems[1].Text;
            temp[2] = listView1.SelectedItems[0].SubItems[2].Text;
            temp[3] = listView1.SelectedItems[0].SubItems[3].Text;
            textBox1.Text = ""; textBox2.Text = ""; textBox3.Text = ""; textBox4.Text = "";
            listView1.SelectedItems[0].Text = temp[0];
            listView1.SelectedItems[0].SubItems[1].Text = temp[1];
            listView1.SelectedItems[0].SubItems[2].Text = temp[2];
            listView1.SelectedItems[0].SubItems[3].Text = temp[3];
        }
        //向上

        private void button1_Click(object sender, EventArgs e)
        {   
            if (listView1.SelectedItems.Count == 0) return;
          
            if (listView1.SelectedIndices[0] == 0)
            {
                MessageBox.Show("已经是第一行了");

                save();
                return;
            }
            int x = listView1.SelectedIndices[0];
            temp[0] = listView1.Items[x - 1].Text;
            temp[1] = listView1.Items[x - 1].SubItems[1].Text;
            temp[2] = listView1.Items[x - 1].SubItems[2].Text;
            temp[3] = listView1.Items[x - 1].SubItems[3].Text;

             listView1.Items[x - 1].Text= listView1.SelectedItems[0].Text;
             listView1.Items[x - 1].SubItems[1].Text=listView1.SelectedItems[0].SubItems[1].Text ;
             listView1.Items[x - 1].SubItems[2].Text = listView1.SelectedItems[0].SubItems[2].Text;
             listView1.Items[x - 1].SubItems[3].Text = listView1.SelectedItems[0].SubItems[3].Text;


            listView1.SelectedItems[0].Text = temp[0];
            listView1.SelectedItems[0].SubItems[1].Text = temp[1] ;
            listView1.SelectedItems[0].SubItems[2].Text= temp[2];
            listView1.SelectedItems[0].SubItems[3].Text = temp[3];


            save();
            listView1.SelectedItems.Clear();


        }
        //向下
        private void button2_Click(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count == 0) return;

            if (listView1.SelectedIndices[0] ==listView1.Items.Count-1)
            {
                MessageBox.Show("已经是最后一行了");

                save();
                return;
            }
            int x = listView1.SelectedIndices[0];
            temp[0] = listView1.Items[x + 1].Text;
            temp[1] = listView1.Items[x + 1].SubItems[1].Text;
            temp[2] = listView1.Items[x + 1].SubItems[2].Text;
            temp[3] = listView1.Items[x + 1].SubItems[3].Text;

            listView1.Items[x + 1].Text = listView1.SelectedItems[0].Text;
            listView1.Items[x + 1].SubItems[1].Text = listView1.SelectedItems[0].SubItems[1].Text;
            listView1.Items[x + 1].SubItems[2].Text = listView1.SelectedItems[0].SubItems[2].Text;
            listView1.Items[x + 1].SubItems[3].Text = listView1.SelectedItems[0].SubItems[3].Text;


            listView1.SelectedItems[0].Text = temp[0];
            listView1.SelectedItems[0].SubItems[1].Text = temp[1];
            listView1.SelectedItems[0].SubItems[2].Text = temp[2];
            listView1.SelectedItems[0].SubItems[3].Text = temp[3];


            save();
            listView1.SelectedItems.Clear();
        }

        private void button3_Click(object sender, EventArgs e)
        {  //删除
            for(int i = listView1.SelectedItems.Count - 1; i >= 0; i--)
            {
                ListViewItem item = listView1.SelectedItems[i];
                listView1.Items.Remove(item);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            listView1.Items.Add(textBox1.Text);
            listView1.Items[listView1.Items.Count - 1].SubItems.Add(textBox2.Text);
            listView1.Items[listView1.Items.Count - 1].SubItems.Add(textBox3.Text);
            listView1.Items[listView1.Items.Count - 1].SubItems.Add(textBox4.Text);
        }
    }
}
