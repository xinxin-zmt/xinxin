﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 随机控件
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public class MyButton : Button
        {
            public MyButton()
            {
                this.Location = new Point(10, 10);
            }
            

        }
        private void Form1_Load(object sender, EventArgs e)
        {
            timer1.Enabled = true;
         
        }
        int i = 0;
        int a = 0, b = 0, c = 0, d = 0;

        private void timer2_Tick(object sender, EventArgs e)
        {
           

        }

        private void button2_Click(object sender, EventArgs e)
        {
            foreach (Control ctr in panel1.Controls)
            {
                if (ctr is TextBox)
                {
                    for (int j = 0; j < 5; j++)
                    {
                        ctr.Location = new Point(ctr.Location.X, ctr.Location.Y + 80);
                        Thread.Sleep(100);
                    }
                }

            }

            foreach (Control ctr in panel1.Controls)
            {
                if (ctr is Button)
                {
                    for (int j = 0; j < 5; j++)
                    {
                        ctr.Location = new Point(ctr.Location.X, ctr.Location.Y + 80);
                        Thread.Sleep(100);
                    }
                }

            }
            foreach (Control ctr in panel1.Controls)
            {
                if (ctr is RadioButton)
                {
                    for (int j = 0; j < 5; j++)
                    {
                        ctr.Location = new Point(ctr.Location.X, ctr.Location.Y + 80);
                        Thread.Sleep(100);
                    }
                }

            }
            foreach (Control ctr in panel1.Controls)
            {
                if (ctr is CheckBox)
                {
                    for (int j = 0; j < 5; j++)
                    {
                        ctr.Location = new Point(ctr.Location.X, ctr.Location.Y + 80);
                        Thread.Sleep(100);
                    }
                }

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            panel1.Controls.Clear();
            timer1.Enabled = true;
            i = 0;
            a = 0; b = 0; c = 0; d = 0;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            i++;
            if (i == 11)
            {
                timer1.Enabled = false;
                textBox1.Text = "一共产生了"+a+"个文本框和"+b+"个按钮" + c + "个单选框" + d + "个复选框";
                i = 0;
              //  a = 0; b = 0; c = 0; d = 0;
              
                return;
            }           
               Random random = new Random();
               int choice =random.Next(0,4);
               textBox1.Text = choice.ToString();
            if (choice == 0)//文本框
            {
                a++;
                TextBox text = new TextBox();
                text.Location = new Point(0, 20 * a);
                text.Text = "我是文本框" + a;
                panel1.Controls.Add(text);
                return;
            }
            else if (choice == 1)//按钮
            {
                b++;
                Button button = new Button();
                button.Location = new Point(150, b * 20);
                button.Text ="按钮"+b;
                panel1.Controls.Add(button);
                 return;
            }
            else if (choice == 2)//单选框
            {
                c++;
                RadioButton radio = new RadioButton();
                radio.Location = new Point(250, c * 20);
                radio.Text = "单选框" + c;
                panel1.Controls.Add(radio);
                return;
            }
            else if (choice == 3)//复选框
            {
                d++;
                CheckBox check = new CheckBox();
                check.Location = new Point(400, d * 20);
                check.Text = "复选框" + d;
                panel1.Controls.Add(check);
                return;
            }
            
        }
    }
}
