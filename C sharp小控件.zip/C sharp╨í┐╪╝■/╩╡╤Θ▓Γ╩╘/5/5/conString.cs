﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _5
{
    public class conString
    {
        public static string connstr = "Data Source=.\\SQL2016;" + "Initial Catalog=examDB;Integrated Security=true";

        public conString(string str)
        {
            connstr = str;
        }
    }
}
