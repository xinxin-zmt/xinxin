﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;

namespace _5
{
    public class concmd
    {
        //创建cmd
        public static SqlCommand creatcmd(string sql)
        {
            SqlConnection conn = confactory.getcon();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = sql;
            return cmd;
        }

        //parament
        public static DataTable table(string sql, SqlParameter[] para)
        {
            SqlCommand cmd = creatcmd(sql);
            if (para != null)
            {
                cmd.Parameters.AddRange(para);
            }
            DataTable datatable = new DataTable("table");
            SqlDataAdapter sda = new SqlDataAdapter();
            sda.SelectCommand = cmd;
            sda.Fill(datatable);
            cmd.Dispose();
            cmd.Parameters.Clear();
            return datatable;

        }

        //执行parament
        public static int content(string sql, SqlParameter[] para)
        {
            SqlCommand cmd = creatcmd(sql);
            try
            {
                cmd.Connection.Open();
                if (para != null)
                {
                    cmd.Parameters.AddRange(para);
                }
                return (int)cmd.ExecuteNonQuery();
            }
            catch (Exception)
            {
                return 0;
            }
            finally
            {
                cmd.Connection.Close();
            }
        }
        //需要put
        public static int content2(string sql, SqlParameter[] para)
        {
            SqlCommand cmd = creatcmd(sql);
            try
            {
                cmd.Connection.Open();
                if (para != null)
                {
                    cmd.Parameters.AddRange(para);
                }
                return (int)cmd.ExecuteScalar();
            }
            catch (Exception)
            {
                return 0;
            }
            finally
            {
                cmd.Connection.Close();
            }
        }

    }
}
