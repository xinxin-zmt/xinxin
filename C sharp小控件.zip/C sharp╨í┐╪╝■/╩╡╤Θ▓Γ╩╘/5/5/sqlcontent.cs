﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;

namespace _5
{
    public class sqlcontent
    {
        public static DataTable dt(string sql, SqlParameter[] para)
        {
            if (concmd.table(sql, para) != null)
            {
                return concmd.table(sql, para);
            }
            else
            {
                return null;
            }
        }
        public static DataTable dt(string sql)
        {
            if (concmd.table(sql, null) != null)
            {
                return concmd.table(sql, null);
            }
            else
            {
                return null;
            }
        }
        public static int content(string sql)
        {
            return concmd.content(sql, null);
        }
        public static int content(string sql, SqlParameter[] para)
        {
            return concmd.content(sql, para);
        }

        public static int content2(string sql)
        {
            return concmd.content2(sql, null);
        }
        public static int content2(string sql, SqlParameter[] para)
        {
            return concmd.content2(sql, para);
        }
        public static SqlParameter[] createSqlparameter(string[] a, string[] b)
        {
            List<SqlParameter> list = new List<SqlParameter>();
            for (int i = 0; i < a.Length; i++)
            {
                list.Add(new SqlParameter(b[i], a[i]));

            }
            SqlParameter[] parameters = list.ToArray();
            return parameters;

        }
    }
}
