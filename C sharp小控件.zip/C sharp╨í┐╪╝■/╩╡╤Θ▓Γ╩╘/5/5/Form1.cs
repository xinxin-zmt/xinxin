﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            listView1.AutoResizeColumns(ColumnHeaderAutoResizeStyle.HeaderSize);
            listView2.AutoResizeColumns(ColumnHeaderAutoResizeStyle.HeaderSize);
            listView3.AutoResizeColumns(ColumnHeaderAutoResizeStyle.ColumnContent);
            listView1.Visible = true;
            listView2.Visible = false;
            listView3.Visible = false;
            listView4.Visible = false;
            listView1.FullRowSelect = true;
            listView1.GridLines = true;
            listView1.View = View.Details;
            listView2.FullRowSelect = true;
            listView2.GridLines = true;
            listView2.View = View.Details;
            listView3.FullRowSelect = true;
            listView3.GridLines = true;
            listView3.View = View.Details;
            listView4.FullRowSelect = true;
            listView4.GridLines = true;
            listView4.View = View.Details;
            listView1.Columns.Add("课程序号");
            listView1.Columns.Add("课程名");
            string sql1 = "select * from course";
            DataTable dt = sqlcontent.dt(sql1);
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                ListViewItem item = new ListViewItem();
                item.Text = dt.Rows[i][0].ToString();
                item.SubItems.Add(dt.Rows[i][1].ToString());
                listView1.Items.Add(item);
            }

        }

        private void listView1_Click(object sender, EventArgs e)
        {
            
            if (listView1.SelectedItems.Count > 0)
            {
                flag++;
                string sql2 = "select score.Student_Id,Student_Name,Course_Name,Score_Score from Score,Student,Course where 1=1 ";
                string sql3 = sql2 + "and Score.Course_Id=@s0 and Course_Name=@s1 and score.Student_Id=Student.Student_Id";
                SqlParameter[] parameters = new SqlParameter[]
                {
                  new SqlParameter("@s0",listView1.SelectedItems[0].SubItems[0].Text),
                  new SqlParameter("@s1",listView1.SelectedItems[0].SubItems[1].Text)
                };
                DataTable dt2 = sqlcontent.dt(sql3, parameters);
                if (dt2.Rows.Count > 0)
                {
                    listView1.Visible = false;
                    listView2.Visible = true;
                    listView2.Clear();
                    this.listView2.Columns.Add("学生学号");
                    this.listView2.Columns.Add("姓名");
                    this.listView2.Columns.Add("科目");
                    this.listView2.Columns.Add("成绩");
                    for (int i = 0; i < dt2.Rows.Count; i++)
                    {
                    ListViewItem item2 = new ListViewItem();
                    item2.Text = dt2.Rows[i][0].ToString();
                    item2.SubItems.Add(dt2.Rows[i][1].ToString());
                    item2.SubItems.Add(dt2.Rows[i][2].ToString());
                    item2.SubItems.Add(dt2.Rows[i][3].ToString());
                    listView2.Items.Add(item2);
                    }

                }
                else
                {
                    MessageBox.Show("暂无数据");
                }
                
            }

        }
        int flag = 0;

        private void button1_Click(object sender, EventArgs e)
        {
           
            if (flag == 0)
            {
                listView1.Visible = true;
                listView2.Visible = false;
                listView3.Visible = false;
                listView4.Visible = false;
               
            }
            else if(flag==1)
            {
                listView1.Visible = false;
                listView2.Visible = true;
                listView3.Visible = false;
                listView4.Visible = false;
                flag --;
            }else if (flag == 2)
            {
                listView1.Visible = false;
                listView3.Visible = true;
                listView2.Visible = false;
                listView4.Visible = false;
                flag--;
            }
            else
            {
                listView1.Visible = false;
                listView4.Visible = true;
                listView2.Visible = false;
                listView3.Visible = false;
                flag--;
            }
           
        }

        private void listView2_Click(object sender, EventArgs e)
        {
            if (listView2.SelectedItems.Count > 0)
            {
                flag++;
                string sql4 = "select Student_Id,Student_Name,Student_Sex,Student_Age,Student_Address,Student_Phone from Student where 1=1 ";
                string sql5 = sql4 + "and Student_Id=@s0";
                SqlParameter[] parameters = new SqlParameter[]
                {
                  new SqlParameter("@s0",listView2.SelectedItems[0].SubItems[0].Text)
                };
                DataTable dt3 = sqlcontent.dt(sql5, parameters);
                if (dt3.Rows.Count > 0)
                {
                    
                    listView2.Visible = false;
                    listView3.Visible = true;
                    listView3.Clear();
                    this.listView3.Columns.Add("学号");
                    this.listView3.Columns.Add("学生姓名");
                    this.listView3.Columns.Add("性别");
                    this.listView3.Columns.Add("年龄");
                    this.listView3.Columns.Add("籍贯");
                    this.listView3.Columns.Add("联系方式");
                    for (int i = 0; i < dt3.Rows.Count; i++)
                    {
                        ListViewItem item3 = new ListViewItem();
                        item3.Text = dt3.Rows[i][0].ToString();
                        item3.SubItems.Add(dt3.Rows[i][1].ToString());
                        item3.SubItems.Add(dt3.Rows[i][2].ToString());
                        item3.SubItems.Add(dt3.Rows[i][3].ToString());
                        item3.SubItems.Add(dt3.Rows[i][4].ToString());
                        item3.SubItems.Add(dt3.Rows[i][5].ToString());
                        listView3.Items.Add(item3);
                    }

                }
               
            }
        }

        private void listView3_Click(object sender, EventArgs e)
        {
            if (listView3.SelectedItems.Count > 0)
            {
                flag++;
                string sql6 = "select Teacher_Name,Teacher_Sex,Teacher_Age,Teacher_Address,Teacher_Phone from Student,Teacher where 1=1 ";
                string sql7 = sql6 + "and Student_Id=@s2 and Student.Department_Id=Teacher.Department_Id ";
                SqlParameter[] parameters = new SqlParameter[]
               {
                  new SqlParameter("@s2",listView3.SelectedItems[0].SubItems[0].Text)
               };
                DataTable dt4 = sqlcontent.dt(sql7,parameters);
                if (dt4.Rows.Count > 0)
                {

                    listView3.Visible = false;
                    listView4.Visible = true;
                    listView4.Clear();
                    this.listView4.Columns.Add("教师姓名");
                    this.listView4.Columns.Add("性别");
                    this.listView4.Columns.Add("年龄");
                    this.listView4.Columns.Add("籍贯");
                    this.listView4.Columns.Add("联系方式");
                    for (int i = 0; i < dt4.Rows.Count; i++)
                    {
                        ListViewItem item4 = new ListViewItem();
                        item4.Text = dt4.Rows[i][0].ToString();
                        item4.SubItems.Add(dt4.Rows[i][1].ToString());
                        item4.SubItems.Add(dt4.Rows[i][2].ToString());
                        item4.SubItems.Add(dt4.Rows[i][3].ToString());
                        item4.SubItems.Add(dt4.Rows[i][4].ToString());
                        listView4.Items.Add(item4);
                    }

                }

            }
        }
    }
}
