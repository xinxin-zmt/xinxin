﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _6
{
    public class conString
    {
        public static string connstr = "Data Source=.\\SQL2016;Initial Catalog=ExamDB;uid=sa;pwd=123";

        public conString(string str)
        {
            connstr = str;
        }
    }
}
