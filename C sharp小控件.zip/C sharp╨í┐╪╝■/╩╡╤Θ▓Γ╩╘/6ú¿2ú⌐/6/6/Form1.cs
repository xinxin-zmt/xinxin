﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace _6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            change();
            listView1.FullRowSelect = true;
            
        }
        public void creatview(DataTable dt)
        {
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                listView1.Items.Add(dt.Rows[i][0].ToString());
                for(int j = 1; j < dt.Columns.Count; j++)
                {
                    listView1.Items[i].SubItems.Add(dt.Rows[i][j].ToString());
                }
            }
            listView1.AutoResizeColumns(ColumnHeaderAutoResizeStyle.HeaderSize);          
        }
      
        string[] vs = new string[4];
        private void listView1_DoubleClick(object sender, EventArgs e)
        {
            flag++;
            if (flag > 3) flag = 3;
            change();
            changeWidth();
        }
        int flag;
       public void change()
        {              
            if (flag == 0)//第一个界面
            {
                listView1.Clear();
                listView1.Columns.Add("课程编号");
                listView1.Columns.Add("课程名称");
                string D = "select * from Course";
                DataTable Dsql = sqlcontent.dt(D);
                creatview(Dsql);
            }else if (flag == 1)//第二界面
            {
                
                if (vs[1] == null)
                {
                    vs[1] = listView1.SelectedItems[0].SubItems[1].Text;
                }               
                string sql = "select Student.Student_Id,Student.Student_Name,Course.Course_Name,Score.Score_Score from Student,Score,Course  where Course.Course_Id = Score.Course_Id and Student.Student_Id = Score.Student_Id and Course_Name = @selected";
                SqlParameter[] sqls = new SqlParameter[]
                {
                new SqlParameter("@selected",vs[1])
                };
                DataTable dt1 = sqlcontent.dt(sql, sqls);
                if (dt1.Rows.Count == 0)
                {
                    MessageBox.Show("暂无");
                    flag = 1;
                    return;
                }
                listView1.Clear();
                listView1.Columns.Add("学生学号");
                listView1.Columns.Add("学生姓名");
                listView1.Columns.Add("课程名称");
                listView1.Columns.Add("成绩");                               
                creatview(dt1);
            }else if (flag == 2)
            {
                if (vs[2] == null)
                {
                    vs[2] = listView1.SelectedItems[0].SubItems[0].Text;
                }
                string sql = "  SELECT [Student_Id] ,[Student_Name],[Student_Sex],[Student_Age] ,[Student_Address],[Student_Phone] FROM [Student] where [Student_Id]=@id";
                SqlParameter[] sqls = new SqlParameter[]
                {
                new SqlParameter("@id",vs[2])
                };
                DataTable dt1 = sqlcontent.dt(sql, sqls);
                listView1.Clear();
                listView1.Columns.Add("学号");
                listView1.Columns.Add("姓名");
                listView1.Columns.Add("性别");
                listView1.Columns.Add("年龄");
                listView1.Columns.Add("籍贯");
                listView1.Columns.Add("联系方式");            
                creatview(dt1);
            }else if (flag == 3)
            {
                if (vs[3] == null)
                {
                    vs[3] = listView1.SelectedItems[0].SubItems[0].Text;
                }
                string sql = "   select [Teacher_Name],[Teacher_Sex] ,[Teacher_Age],[Teacher_Address] ,[Teacher_Phone] from Student,Teacher  where Teacher.Department_Id = Student.Department_Id and Student_Id =@id";
                SqlParameter[] sqls = new SqlParameter[]
                {
                new SqlParameter("@id",vs[3])
                };
                DataTable dt1 = sqlcontent.dt(sql, sqls);
                listView1.Clear();                
                listView1.Columns.Add("教师姓名");
                listView1.Columns.Add("性别");
                listView1.Columns.Add("年龄");
                listView1.Columns.Add("籍贯");
                listView1.Columns.Add("联系方式");
                creatview(dt1);
            }

        }

        
        private void button1_Click(object sender, EventArgs e)
        {
            flag--;
            if (flag < 0) flag = 0; 
            change();
            
        }
        public void changeWidth()
        {
            
            if (flag == 0)
            {
                listView1.Width = 100;               
            }
            else if (flag == 1)
            {
                listView1.Width = 325;
              
            }
            else if (flag == 2)
            {
                listView1.Width = 450;               
            }
            this.Width = listView1.Width + 20;
            button1.Left = this.Width /5 + 20;
        }
       
    }
}
