﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 实验1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            treeView1.Nodes.Add("0", "表");
            string sql = "select * from Department";
            DataTable dt = sqlcontent.dt(sql);
            for (int i = 0; i < dt.Rows.Count; i++)
            {
               
                treeView1.Nodes["0"].Nodes.Add(dt.Rows[i][1].ToString());
                treeView1.Font = new Font("宋体", 15);
            }
            listView1.Columns.Add("学号");
            listView1.Columns.Add("姓名",80);
            listView1.Columns.Add("性别",70);
            listView1.Columns.Add("年龄",70);
            listView1.Columns.Add("籍贯");
            listView1.Columns.Add("联系方式",100);

            listView2.Columns.Add("姓名");
            listView2.Columns.Add("性别");
            listView2.Columns.Add("年龄");
            listView2.Columns.Add("籍贯");
            listView2.Columns.Add("联系方式",100);
        }

        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {
            listView1.Items.Clear();
            listView2.Items.Clear();
            if (treeView1.SelectedNode.Text!="表")
            {
           
            string a = treeView1.SelectedNode.Text;
            string sql = "select * from Department where Department_Name=@B";
            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@B",a)
             };
            DataTable dt = sqlcontent.dt(sql, parameters);
            string b = dt.Rows[0][0].ToString();
            string sql1 = "select * from Teacher where Department_Id=@c";
            SqlParameter[] parameters1 = new SqlParameter[]
            {
                new SqlParameter("@c",b)
             };
            DataTable dt1 = sqlcontent.dt(sql1, parameters1);
            for (int i = 0; i < dt1.Rows.Count; i++)
            {
                listView2.Items.Add(dt1.Rows[i][1].ToString());
                listView2.Items[i].SubItems.Add(dt1.Rows[i][3].ToString());
                listView2.Items[i].SubItems.Add(dt1.Rows[i][4].ToString());
                listView2.Items[i].SubItems.Add(dt1.Rows[i][5].ToString());
                listView2.Items[i].SubItems.Add(dt1.Rows[i][6].ToString());
            }         
            string sql2 = "select * from Student where Department_ID=@c";
            SqlParameter[] parameters2 = new SqlParameter[]
            {
                new SqlParameter("@c",b)
             };
            DataTable dt2 = sqlcontent.dt(sql2, parameters1);
            for (int i = 0; i < dt2.Rows.Count; i++)
            {
                listView1.Items.Add(dt2.Rows[i][0].ToString());
                listView1.Items[i].SubItems.Add(dt2.Rows[i][2].ToString());
                listView1.Items[i].SubItems.Add(dt2.Rows[i][3].ToString());
                listView1.Items[i].SubItems.Add(dt2.Rows[i][4].ToString());
                listView1.Items[i].SubItems.Add(dt2.Rows[i][5].ToString());
                listView1.Items[i].SubItems.Add(dt2.Rows[i][6].ToString());
            }
            }
            listView1.Font = new Font("宋体", 15);
            listView2.Font = new Font("宋体", 15);
        }

        private void contextMenuStrip1_Click(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count == 0) return;
            string sql1 = "select * from Score where Student_Id=@c";
            SqlParameter[] parameters1 = new SqlParameter[]
            {
                new SqlParameter("@c",listView1.SelectedItems[0].Text)
             };
            DataTable dt1 = sqlcontent.dt(sql1, parameters1);
            if(dt1.Rows.Count>0)
            {
                MessageBox.Show("已经参加考试");
            }
            else
            {
                string sql = "delete from Student where Student_Id=@username";
                SqlParameter[] parameters = new SqlParameter[]
                {
                    new SqlParameter("@username",listView1.SelectedItems[0].Text)
                };
                sqlcontent.content(sql, parameters);
                listView1.Items.Remove(listView1.SelectedItems[0]);
            }
            
        }

        private void contextMenuStrip2_Click(object sender, EventArgs e)
        {
            if (listView2.SelectedItems.Count == 0) return;
            string sql = "delete from Teacher where Teacher_Name=@username";
            SqlParameter[] parameters = new SqlParameter[]
            {
                    new SqlParameter("@username",listView2.SelectedItems[0].Text)
            };
            sqlcontent.content(sql, parameters);
            listView2.Items.Remove(listView2.SelectedItems[0]);
        }

    }
}
