﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace 实验1
{
    public class confactory
    {
        private static string constr = conString.connstr;
        static SqlConnection conn;
        //获取连接
        public static SqlConnection getcon()
        {
            if (conn == null)
            {
                conn = new SqlConnection();
                conn.ConnectionString = constr;
            }
            if (conn.State == ConnectionState.Closed)
            {
                conn.Open();
            }
            return conn;
        }
        //关闭连接
        public static void closeconn()
        {
            if (conn != null && conn.State == ConnectionState.Open)
            {
                conn.Close();
            }
        }
    }
}
