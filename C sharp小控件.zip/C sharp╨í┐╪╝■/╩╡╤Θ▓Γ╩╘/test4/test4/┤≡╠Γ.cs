﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace test4
{
    public partial class Form2 : Form
    {
        string tb1;
        public Form2(string tb1)
        {
            InitializeComponent();
            this.tb1 = tb1;
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            panel1.Visible = true;
            panel2.Visible = false;
            listView1.View = View.Details;

            listView1.Columns.Add("答题人");
            listView1.Columns.Add("答题日期",100);
            listView1.Columns.Add("答题时间",80);
            listView1.Columns.Add("所用时间",80);
            listView1.Columns.Add("正确率",80);

            listView1.GridLines = true;//显示网格线
            listView1.FullRowSelect = true;//整行选中
            listView1.Scrollable = true;//可滚动
            listView1.MultiSelect = true;//不可复选
          
        }
        int answer1;
        int answer2;
        int answer3;
        void load()
        {
            Random rd = new Random();
            label1.Text = rd.Next(1, 100).ToString();
            label3.Text = rd.Next(1, 100).ToString();
            label6.Text = rd.Next(1, 100).ToString();
            label8.Text = rd.Next(1, 100).ToString();
            label10.Text = rd.Next(1, 100).ToString();
            label12.Text = rd.Next(1, 100).ToString();

            string[] fuhao = new string[] { "+", "-" };
            Random r = new Random();

            int r1 = r.Next(0, 2);
            int r2 = r.Next(0, 2);
            int r3 = r.Next(0, 2);

            label2.Text = fuhao[r1];
            label7.Text = fuhao[r2];
            label11.Text = fuhao[r3];
            
            if (label2.Text == "-")
            {
                answer1 = int.Parse(label1.Text) - int.Parse(label3.Text);
            }
            else
            {
                answer1 = int.Parse(label1.Text) + int.Parse(label3.Text);
            }

            if (label7.Text == "-")
            {
                answer2 = int.Parse(label8.Text) - int.Parse(label6.Text);
            }
            else
            {
                answer2 = int.Parse(label8.Text) + int.Parse(label6.Text);
            }

            if (label11.Text == "-")
            {
                answer3 = int.Parse(label12.Text) - int.Parse(label10.Text);
            }
            else
            {
                answer3 = int.Parse(label12.Text) + int.Parse(label10.Text);
            }
        }

        int i = 0;
        int c = 0;
        void count()
        {
            if (textBox1.Text == answer1.ToString()) {c++;}
            if (textBox2.Text == answer2.ToString()) { c++; }
            if (textBox3.Text == answer3.ToString()) { c++; }
        }
        double tf;
        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "")
            {
                count();
                tf = (double)Math.Round((decimal)(c/3.0), 2);             
                c = 0;
                              
                add();
                i++;
                panel2.Visible = false;
                panel1.Visible = true;
                textBox1.Text = textBox2.Text = textBox3.Text = "";
            }
            else
            {
                MessageBox.Show("请完成所有题目后再提交");
            }                 
        }
        void add()
        {
            ListViewItem item = new ListViewItem();
            listView1.Items.Add(tb1.ToString());
            listView1.Items[i].SubItems.Add(DateTime.Now.ToString("yyyy-MM-dd"));
            DateTime dtl = Convert.ToDateTime(DateTime.Now.ToString("hh:mm:ss"));
            listView1.Items[i].SubItems.Add(DateTime.Now.ToString("hh:mm:ss"));
            TimeSpan span = dtl.Subtract(dte);
            listView1.Items[i].SubItems.Add(span.TotalSeconds+"秒");
            listView1.Items[i].SubItems.Add(tf.ToString());
        }
        
        private void button2_Click(object sender, EventArgs e)
        {
            panel1.Visible = false;
            panel2.Visible = true;
            load();
        }
        DateTime dt1;
        DateTime dt2;
        DateTime dt3;
        DateTime dte;
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            dt1 = Convert.ToDateTime(DateTime.Now.ToString("hh:mm:ss"));
            dte = dt1;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            dt2 = Convert.ToDateTime(DateTime.Now.ToString("hh:mm:ss"));
            if (dte > dt2)
            {
                dte = dt2;
            }          
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            dt3 = Convert.ToDateTime(DateTime.Now.ToString("hh:mm:ss"));
            if (dte > dt3)
            {
                dte = dt2;
            }
        }
    }
}
