﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace test4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sql = "select Users_Account,Users_Password,Users_Usertype " +
               "from Users where Users_Account=@Users_Account";
            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@Users_Account",textBox1.Text)
             };
            DataTable dt = sqlcontent.dt(sql, parameters);
            if (dt.Rows.Count > 0)
            {
                if (textBox2.Text != dt.Rows[0][1].ToString())
                {
                    MessageBox.Show("密码错误");
                    textBox2.Text = "";
                }
                else
                {
                    MessageBox.Show("登录成功");
                    this.Hide();
                    Form2 f2 = new Form2(textBox1.Text);
                    f2.Show();
                    this.textBox2.Text = "";
                }
            }
            else
            {
                MessageBox.Show("用户名不存在");
                textBox1.Text = "";
                textBox2.Text = "";
            }
        }
    }
}
