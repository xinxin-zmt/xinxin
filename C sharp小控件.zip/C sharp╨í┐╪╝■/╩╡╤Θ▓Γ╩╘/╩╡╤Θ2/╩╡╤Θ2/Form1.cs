﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 实验2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            listView1.Columns.Add("学生姓名");
            listView1.Columns.Add("课程名称");
            listView1.Columns.Add("成绩");
            string sql = "SELECT Student_Name,Student_Id FROM Student";
            DataTable dt = sqlcontent.dt(sql);
            comboBox1.DisplayMember = "Student_Name";
            comboBox1.ValueMember = "Student_Id";
            comboBox1.DataSource = dt;
            string sql1 = "SELECT Course_Name,Course_Id FROM Course ";
            DataTable dt1 = sqlcontent.dt(sql1);
            comboBox2.DisplayMember = "Course_Name";
            comboBox2.ValueMember = "Course_Id";
            comboBox2.DataSource = dt1;
            string sql2 = "select Student_Name,Course_Name,Score_Score from student,score,Course where Student.Student_Id=Score.Student_Id and Course.Course_Id=Score.Course_Id";
            DataTable dt2 = sqlcontent.dt(sql2);
            for (int i = 0; i < dt2.Rows.Count; i++)
            {
                listView1.Items.Add(dt2.Rows[i][0].ToString());
                listView1.Items[i].SubItems.Add(dt2.Rows[i][1].ToString());
                listView1.Items[i].SubItems.Add(dt2.Rows[i][2].ToString());
                
            }
            listView1.AutoResizeColumns(ColumnHeaderAutoResizeStyle.ColumnContent);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox2.SelectedValue.ToString()=="" || comboBox1.SelectedValue.ToString() == "")
            {
                MessageBox.Show("请先选择学生姓名和考试科目");
                return;
            }
            if (textBox1.Text == "")
            {
                MessageBox.Show("请填写学生成绩");
                return;
            }
            int a;
            try
            {
                a = int.Parse(textBox1.Text);
            }
            catch (Exception)
            {
                MessageBox.Show("成绩信息不符合格式");
                return;
                throw;
            }
            if (a > 100 || a < 0)
            {
                MessageBox.Show("成绩信息不符合格式");
                return;
            }
            string aa = comboBox1.SelectedValue.ToString();
            string bb= comboBox2.SelectedValue.ToString();
            string sql1 = "select * from Score Where Student_Id='" + aa + "'and Course_Id='" + bb + "'";
            DataTable dt1 = sqlcontent.dt(sql1);
            if(sqlcontent.dt(sql1).Rows.Count>0)
            {
                string sql = "UPDATE Score SET Score_Score = '" + textBox1.Text + "'Where Student_Id='" + aa + "'and Course_Id='" + bb + "'";
                sqlcontent.content(sql);
                listView1.Items.Clear();
                string sql2 = "select Student_Name,Course_Name,Score_Score from student,score,Course where Student.Student_Id=Score.Student_Id and Course.Course_Id=Score.Course_Id";
                DataTable dt2 = sqlcontent.dt(sql2);
                for (int i = 0; i < dt2.Rows.Count; i++)
                {
                    listView1.Items.Add(dt2.Rows[i][0].ToString());
                    listView1.Items[i].SubItems.Add(dt2.Rows[i][1].ToString());
                    listView1.Items[i].SubItems.Add(dt2.Rows[i][2].ToString());

                }
                //MessageBox.Show("已经有数据了");
            }
            else
            {
            string sql = "insert into Score values(@Student_Id,@Course_Id,@Score_Score)";
            SqlParameter[] parameters1 = new SqlParameter[]
            {
                new SqlParameter("@Student_Id",aa),
                new SqlParameter("@Course_Id",bb),
                new SqlParameter("@Score_Score",textBox1.Text),
            };
            if (sqlcontent.content(sql, parameters1) > 0)
            {
                MessageBox.Show("添加成功");
            }
           
            string sql2 = "select Student_Name,Course_Name,Score_Score from student,score,Course where Student.Student_Id=Score.Student_Id and Course.Course_Id=Score.Course_Id";
            DataTable dt2 = sqlcontent.dt(sql2);

                listView1.Items.Add(comboBox1.Text);
                listView1.Items[dt2.Rows.Count-1].SubItems.Add(comboBox2.Text);
                listView1.Items[dt2.Rows.Count - 1].SubItems.Add(textBox1.Text);


                listView1.AutoResizeColumns(ColumnHeaderAutoResizeStyle.ColumnContent);
            }
            
        }
    }
}
