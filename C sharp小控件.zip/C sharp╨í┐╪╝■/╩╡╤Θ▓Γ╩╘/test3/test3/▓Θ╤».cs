﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace test3
{
    public partial class Form2 : Form
    {
        Form1 f1;
        string tb1;
        public Form2(Form1 f1,string tb1)
        {
            InitializeComponent();
            this.f1 = f1;
            this.tb1 = tb1;
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            label1.Text = tb1;
            string sql = "select * from Users where Users_Account=@u";
            SqlParameter[] parameters = new SqlParameter[]
                   {
                           new SqlParameter("u",tb1),
                   };
            DataTable dt = sqlcontent.dt(sql,parameters);
            if (dt.Rows[0][2].ToString()=="0")
            {
                label2.Text = ",欢迎登录，您可以添加学生、删除学生";
            }
            else if (dt.Rows[0][2].ToString()== "1")
            {
                label2.Text = ",欢迎登录，您可以修改学生信息";
            }
            listView1.View = View.Details;
            listView1.Columns.Add("学号");
            listView1.Columns.Add("姓名");
            listView1.Columns.Add("性别",50);
            listView1.Columns.Add("年龄",50);
            listView1.Columns.Add("籍贯");
            listView1.Columns.Add("联系方式",80);
            listView1.Columns.Add("系名称");         

            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = "Data Source=.\\Sql2016;" + "" +
                "Initial Catalog=examDB;Trusted_Connection=SSPI";//数据库连接
            conn.Open();

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn;
            cmd.CommandType = CommandType.Text;
            string sql2 = "select Student_Id,Student_Name,Student_Sex,Student_Age," +
                "Student_Address,Student_Phone,Department.Department_Name from Student," +
                "Department where Student.Department_Id=Department.Department_Id";
            cmd.CommandText = sql2;

            DataSet shuju = new DataSet();
            SqlDataAdapter adt = new SqlDataAdapter();
            adt.SelectCommand = cmd;
            adt.Fill(shuju, "inf");
            DataTable dt2 = shuju.Tables["inf"];
            conn.Close();

            listView1.GridLines = true;//显示网格线
            listView1.FullRowSelect = true;//整行选中
            listView1.Scrollable = true;//可滚动
            listView1.MultiSelect = false;//不可复选

            if (dt2.Rows.Count == 0) return;
            for (int i = 0; i < dt2.Rows.Count; i++)
            {
                listView1.Items.Add(dt2.Rows[i][0].ToString());
                listView1.Items[i].SubItems.Add(dt2.Rows[i][1].ToString());
                listView1.Items[i].SubItems.Add(dt2.Rows[i][2].ToString());
                listView1.Items[i].SubItems.Add(dt2.Rows[i][3].ToString());
                listView1.Items[i].SubItems.Add(dt2.Rows[i][4].ToString());
                listView1.Items[i].SubItems.Add(dt2.Rows[i][5].ToString());
                listView1.Items[i].SubItems.Add(dt2.Rows[i][6].ToString());
            }

            cmd.Dispose();
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar==(char)13)
            {
                listView1.Items.Clear();
                SqlConnection conn = new SqlConnection();
                conn.ConnectionString = "Data Source=.\\Sql2016;" + "" +
                "Initial Catalog=examDB;Integrated Security=true";
                conn.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.Text;
                string sql = "select * from (select Student_Id,Student_Name,Student_Sex,Student_Age," +
                    "Student_Address,Student_Phone,Department.Department_Name from Student," +
                    "Department where Student.Department_Id = Department.Department_Id)aa" +
                    " where student_name like @pd or student_id like @pd ";

                cmd.CommandText = sql;
                cmd.Parameters.Add(new SqlParameter("@pd","%"+textBox1.Text+"%"));

                DataSet shuju = new DataSet();
                SqlDataAdapter adt = new SqlDataAdapter();
                adt.SelectCommand = cmd;
                adt.Fill(shuju, "inf");
                DataTable dt = shuju.Tables["inf"];
                conn.Close();

                listView1.GridLines = true;//显示网格线
                listView1.FullRowSelect = true;//整行选中
                listView1.Scrollable = true;//可滚动
                listView1.MultiSelect = false;//不可复选

                if (dt.Rows.Count == 0) return;
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                listView1.Items.Add(dt.Rows[i][0].ToString());
                listView1.Items[i].SubItems.Add(dt.Rows[i][1].ToString());
                listView1.Items[i].SubItems.Add(dt.Rows[i][2].ToString());
                listView1.Items[i].SubItems.Add(dt.Rows[i][3].ToString());
                listView1.Items[i].SubItems.Add(dt.Rows[i][4].ToString());
                listView1.Items[i].SubItems.Add(dt.Rows[i][5].ToString());
                listView1.Items[i].SubItems.Add(dt.Rows[i][6].ToString());
                }
                cmd.Dispose();
            }
           
        }
    }
}
