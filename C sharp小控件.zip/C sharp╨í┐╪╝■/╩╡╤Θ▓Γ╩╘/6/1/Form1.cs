﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            listView1.FullRowSelect = true;
            this.treeView1.Nodes.Add("0","系");
            comboBox1.Items.Add("男");
            comboBox1.Items.Add("女");
            string sql1 = "select * from Department";
            DataTable dt = sqlcontent.dt(sql1);
            for(int i=0;i<dt.Rows.Count; i++)
            {
                treeView1.Nodes["0"].Nodes.Add(dt.Rows[i][0].ToString(), dt.Rows[i][1].ToString());
                comboBox2.Items.Add(dt.Rows[i][1].ToString());
            }
            listView1.GridLines = true;
            listView1.View = View.Details;
            
            this.listView1.Columns.Add("教师工号");
            this.listView1.Columns.Add("姓名");
            this.listView1.Columns.Add("性别");
            this.listView1.Columns.Add("年龄");
            this.listView1.Columns.Add("籍贯");
            this.listView1.Columns.Add("联系方式");
            string sql2 = "select Teacher_Id,Teacher_Name ,Teacher_Sex," +
                "Teacher_Age,Teacher_Address,Teacher_Phone from dbo.Teacher";
            DataTable data = sqlcontent.dt(sql2);
            for (int i = 0; i < data.Rows.Count; i++)
            {
                ListViewItem item = new ListViewItem();
                item.Text = data.Rows[i][0].ToString();
                item.SubItems.Add(data.Rows[i][1].ToString());
                item.SubItems.Add(data.Rows[i][2].ToString());
                item.SubItems.Add(data.Rows[i][3].ToString());
                item.SubItems.Add(data.Rows[i][4].ToString());
                item.SubItems.Add(data.Rows[i][5].ToString());
                listView1.Items.Add(item);
            }
            
        }

        private void listView1_Click(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count > 0)
            {
                try
                {
                    string x0 = listView1.SelectedItems[0].SubItems[0].Text.ToString();
                    string x1 = listView1.SelectedItems[0].SubItems[1].Text.ToString();
                    string x2 = listView1.SelectedItems[0].SubItems[2].Text.ToString();
                    string x3 = listView1.SelectedItems[0].SubItems[3].Text.ToString();
                    string x4 = listView1.SelectedItems[0].SubItems[4].Text.ToString();
                    string x5 = listView1.SelectedItems[0].SubItems[5].Text.ToString();
                    textBox1.Text = x0;
                    textBox2.Text = x1;
                    textBox3.Text = x3;
                    comboBox1.Text = x2;
                    textBox4.Text = x4;
                    textBox5.Text = x5;
                    comboBox2.Text = treeView1.SelectedNode.Text;
                    textBox1.Enabled = false;
                    comboBox2.Enabled = true;
                }
                catch (Exception)
                {
                    MessageBox.Show(e.ToString());
                    throw;
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sql = "select Department_Id from Department where Department_Name=@name";
             SqlParameter[] parameters2 = new SqlParameter[]
            {
                new SqlParameter ("@name",comboBox2.Text),
            };
            DataTable dt2 = sqlcontent.dt(sql, parameters2); 
            
            string sql6 = "update teacher set Teacher_Name=@name," +
                "Teacher_Sex=@sex,Teacher_Age=@age,Teacher_Address=@address," +
                "Teacher_Phone=@phone,Department_Id=@department where Teacher_Id=@num";

            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter ("@num",textBox1.Text),
                new SqlParameter ("@name",textBox2.Text),
                new SqlParameter("@sex", comboBox1.Text),
                new SqlParameter("@age", textBox3.Text),
                new SqlParameter("@address", textBox4.Text),
                new SqlParameter("@phone", textBox5.Text),
                new SqlParameter("@department",dt2.Rows[0][0].ToString() ),
            };
           
            DataTable dt = sqlcontent.dt(sql6, parameters);
            
            MessageBox.Show("教师信息修改成功");

            listView1.SelectedItems[0].SubItems[1].Text = textBox2.Text;
            listView1.SelectedItems[0].SubItems[3].Text = textBox3.Text;
            listView1.SelectedItems[0].SubItems[4].Text = textBox4.Text;
            listView1.SelectedItems[0].SubItems[5].Text = textBox5.Text;
            listView1.SelectedItems[0].SubItems[2].Text = comboBox1.Text;

            textBox1.Text = textBox2.Text = textBox3.Text = textBox4.Text = textBox5.Text = "";
            comboBox1.Text = comboBox2.Text = "";
            listView1.SelectedItems[0].Remove();

        }

        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {
            string sql3 = "select Teacher_Id,Teacher_Name ,Teacher_Sex," +
                "Teacher_Age,Teacher_Address,Teacher_Phone from dbo.Teacher ," +
                "dbo.Department where 1=1 ";
            string sql4 = "and Department.Department_Name=@s1 and " +
                "Teacher.Department_Id=Department.Department_Id ";
            string sql5 = sql3 + sql4;
            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@s1",treeView1.SelectedNode.Text)
            };
            DataTable dt2 = sqlcontent.dt(sql5, parameters);
            listView1.Items.Clear();
            for (int i = 0; i < dt2.Rows.Count; i++)
            {
                ListViewItem item = new ListViewItem();
                item.Text = dt2.Rows[i][0].ToString();
                item.SubItems.Add(dt2.Rows[i][1].ToString());
                item.SubItems.Add(dt2.Rows[i][2].ToString());
                item.SubItems.Add(dt2.Rows[i][3].ToString());
                item.SubItems.Add(dt2.Rows[i][4].ToString());
                item.SubItems.Add(dt2.Rows[i][5].ToString());
                listView1.Items.Add(item);
            }
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            int key = Convert.ToInt32(e.KeyChar);
            if (!(48 <= key && key <= 58 || key == 8)) //数字、 Backspace
            {
                this.Text = "keyChar:" + key.ToString();
                e.Handled = true;
            }
            else this.Text = "";
        }
    } 
}
