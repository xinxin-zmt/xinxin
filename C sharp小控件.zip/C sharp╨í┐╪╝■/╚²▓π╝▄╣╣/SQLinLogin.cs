﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 实验五
{
    public class SQLinLogin
    {
        public static string Logsql = "select* from users where username=@user";
        public static DataTable dt(string username)
        {
            string[] a = { username };
            string[] b = { "@user" };
            DataTable dt = sqlcontent.dt( Logsql,Database.createSqlparameter(a, b));
            return dt;
        }
    }
}
