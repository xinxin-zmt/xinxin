﻿using System.Data;
using System.Windows.Forms;
namespace 实验五
{
    public class Login
    {
        public static bool userLogin(ref TextBox textBox1,ref TextBox textBox2)
        {
            DataTable dt = SQLinLogin.dt(textBox1.Text);
            if (dt.Rows.Count > 0)
            {
                if (textBox2.Text != dt.Rows[0][1].ToString())
                {
                    MessageBox.Show("密码错误");
                    textBox2.Text = "";
                }
                else
                {
                    return true;
                }
            }
            else
            {
                MessageBox.Show("用户名不存在");
                textBox1.Text = "";
                textBox2.Text = "";               
            }
            return false;
        }
    }
}
