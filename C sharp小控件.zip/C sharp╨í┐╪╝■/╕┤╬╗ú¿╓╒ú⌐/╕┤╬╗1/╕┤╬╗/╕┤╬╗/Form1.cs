﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 复位
{
    public partial class Form1 : Form
    {
        
        int xx1, xx2, xx3, xx4;               //记录最一开始每一个按钮的位置
        int yy1, yy2, yy3, yy4;
        public Form1()
        {
            InitializeComponent();
            xx1 = button1.Location.X;
            yy1 = button1.Location.Y;
            xx2 = button2.Location.X;
            yy2 = button2.Location.Y;
            xx3 = button3.Location.X;
            yy3 = button3.Location.Y;
            xx4 = button4.Location.X;
            yy4 = button4.Location.Y;
            timer1.Enabled = false;
        }
        
        
        private void button6_Click(object sender, EventArgs e)      //让每个按钮的位置回到初始状态
        {
            button1.Location = new Point(xx1, yy1);
            button2.Location = new Point(xx2, yy2);
            button3.Location = new Point(xx3, yy3);
            button4.Location = new Point(xx4, yy4);
        }


        
        
        private void button5_Click(object sender, EventArgs e)         //点击复位按钮 1234按钮可用
        {
            button1.Enabled = true;
            button2.Enabled = true;
            button3.Enabled = true;
            button4.Enabled = true;
        }


        int x1,x2;
        int y1,y2;
        //判断并获取两个按钮的坐标位置并存储到x12，y12中
        public void CP()
        {
            if (f1 && f2)
            {
                x1 = button1.Left;
                y1 = button1.Top;
                x2 = button2.Left;
                y2 = button2.Top;
            }
            if (f1 && f3)
            {
                x1 = button1.Left;
                y1 = button1.Top;
                x2 = button3.Left;
                y2 = button3.Top;
            }
            if (f1 && f4)
            {
                x1 = button1.Left;
                y1 = button1.Top;
                x2 = button4.Left;
                y2 = button4.Top;
            }
            if (f2 && f3)
            {
                x1 = button2.Left;
                y1 = button2.Top;
                x2 = button3.Left;
                y2 = button3.Top;
            }
            if (f2 && f4)
            {
                x1 = button2.Left;
                y1 = button2.Top;
                x2 = button4.Left;
                y2 = button4.Top;
            }
            if (f3 && f4)
            {
                x1 = button3.Left;
                y1 = button3.Top;
                x2 = button4.Left;
                y2 = button4.Top;
            }
            timer1.Enabled = true;
        }

        private void timer1_Tick(object sender, EventArgs e)   //计时器每个周期里面执行一次按钮的位移
        {
            if (f1 && f2)
            {
                change(button1, button2);
                
            }
            if (f1 && f3)
            {
                change(button1, button3);
            }
            if (f1 && f4)
            {
                change(button1, button4);
            }
            if (f2 && f3)
            {
                change(button2, button3);
            }
            if (f2 && f4)
            {
                change(button2, button4);
            }
            if (f3 && f4)
            {
                change(button3, button4);
            }
            
        }


        
        bool f1, f2, f3, f4;               //点击两个按钮用f1234判断是否点击到，存到f1234里面
        private void button1_Click(object sender, EventArgs e)
        {
            f1 = true;
            CP();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            f2 = true;
            CP();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            f3 = true;
            CP();
        }
        private void button4_Click(object sender, EventArgs e)
        {
            f4 = true;
            CP();
        }
        
        
        public void change(Button bt1,Button bt2)//交换位置
        {
         
            if (x1 < x2)                        //x方向位置交换
            {
                bt1.Left += 20;
                bt2.Left -= 20;
                if (bt1.Location.X > x2)        //如果移多了就搞回来
                {
                    bt1.Left = x2;
                    bt2.Left = x1;
                    timer1.Stop();
                    button1.Enabled = false;
                    button2.Enabled = false;
                    button3.Enabled = false;
                    button4.Enabled = false;
                    f1 = false;f2 = false;f3 = false;f4 = false;
                }
                
            }
            else if(x1>x2)
            {
                bt1.Left -= 20;
                bt2.Left += 20;
                if (bt1.Location.X < x2)
                {
                    bt1.Left = x2;
                    bt2.Left = x1;
                    timer1.Stop();
                    button1.Enabled = false;
                    button2.Enabled = false;
                    button3.Enabled = false;
                    button4.Enabled = false;
                    f1 = false; f2 = false; f3 = false; f4 = false;
                }
            }
            else
            {
                bt1.Left = bt2.Left;
            }
            if (y1< y2)                            //y方向的位置交换
            {
                bt1.Top += 20;
                bt2.Top -= 20;
                if (bt1.Location.Y > y2)
                {
                    bt1.Top = y2;
                    bt2.Top = y1;
                    timer1.Stop();
                    button1.Enabled = false;
                    button2.Enabled = false;
                    button3.Enabled = false;
                    button4.Enabled = false;
                    f1 = false; f2 = false; f3 = false; f4 = false;
                }
            }
            else if(y1>y2)
            {
                bt1.Top -= 20;
                bt2.Top += 20;
                if (bt1.Location.Y < y2)
                {
                    bt1.Top = y2;
                    bt2.Top = y1;
                    timer1.Stop();
                    button1.Enabled = false;
                    button2.Enabled = false;
                    button3.Enabled = false;
                    button4.Enabled = false;
                    f1 = false; f2 = false; f3 = false; f4 = false;
                }
            }
            else
            {
                bt1.Top = bt2.Top;
            }

        }
    }
}
