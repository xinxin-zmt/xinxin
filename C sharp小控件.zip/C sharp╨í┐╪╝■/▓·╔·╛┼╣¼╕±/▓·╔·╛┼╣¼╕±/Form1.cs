﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 产生九宫格
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Button[] buttons = new Button[9];
        private void button1_Click(object sender, EventArgs e)
        {
            panel1.Controls.Clear();
            int x = 0;
            Random random = new Random();                  
            int[] a = new int[10];
            for (int i = 0; i < 10; i++)
            {
                 a[i] = random.Next(1, 10);
                for (int j = 0; j <i ;j++ )
                {
                    if (a[j] == a[i])
                    {
                        if (i == 9) break;
                        j = -1;
                        a[i] = random.Next(1, 10);
                        continue;
                        
                    }
                  
                }
                
            }

            for (int i = 0; i < 9; i++)
            {

                buttons[i] = new Button();
                buttons[i].Text = a[i].ToString();
                buttons[i].Size = new Size(100, 100);
                buttons[i].Location = new Point((i * 100) % 300, 100 * x);
                if (buttons[i].Left + buttons[i].Width >= panel1.Width - 100)
                {
                    x++;
                }
                this.panel1.Controls.Add(buttons[i]);
                buttons[i].Click += new EventHandler(aaa);

            }
           
           

        }
     void aaa(object sender, EventArgs e)
        {
            string a = this.ActiveControl.Text;
            MessageBox.Show(a);
        }
        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
